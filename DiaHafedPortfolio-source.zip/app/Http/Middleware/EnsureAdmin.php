<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class EnsureAdmin {
    public function handle(Request $request, Closure $next) {
        if (!$request->user()) return redirect()->guest(route('login'));
        abort_unless($request->user()->is_admin, 403);
        // First-time administrators must replace the default password before using the dashboard.
        if ($request->user()->mustChangePassword() && !$request->routeIs('admin.password.*')) {
            return redirect()->route('admin.password.edit');
        }
        return $next($request);
    }
}
