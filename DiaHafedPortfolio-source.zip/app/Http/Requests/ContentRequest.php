<?php
namespace App\Http\Requests;
use App\Support\PortfolioFields;
use Illuminate\Foundation\Http\FormRequest;
class ContentRequest extends FormRequest {
    public function authorize(): bool { return (bool) $this->user()?->is_admin; }
    public function rules(): array {
        $section = $this->route('section') ?? $this->route('item')?->section;
        $isItem = $this->route('item') || $this->routeIs('admin.items.store');
        $fields = $isItem ? PortfolioFields::item($section->type) : PortfolioFields::section($section->type);
        $rules = ['title'=>'required|string|max:255', 'subtitle'=>'nullable|string|max:255', 'body'=>'nullable|string|max:20000', 'position'=>'required|integer|min:0|max:10000', 'is_visible'=>'nullable|boolean', 'data'=>['nullable','array:'.implode(',',array_keys($fields))]];
        foreach ($fields as $key=>$label) {
            $rules['data.'.$key] = ['nullable','string','max:10000'];
            if (in_array($key, ['page_width','page_height'])) $rules['data.'.$key] = ['nullable','integer','min:100','max:500'];
            if (array_key_exists($key, \App\Support\PortfolioTheme::colors())) $rules['data.'.$key] = ['nullable', 'string', 'regex:/^#[0-9a-fA-F]{6}$/D'];
            if (in_array($key, ['url','cta_url','secondary_url'])) $rules['data.'.$key][] = 'regex:~^(https?://[^\s]+|/[a-zA-Z0-9/_\-.#?=&%]*|\#[a-zA-Z][\w-]*)$~';
            if ($key === 'email') $rules['data.'.$key][] = 'email';
            if (PortfolioFields::media($key)) {
                $rules['data.'.$key][] = 'regex:~^/(?!/)[a-zA-Z0-9/_\-.]+$~';
                $rules['upload_'.$key] = match ($key) {
                    'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:10240',
                    'model_url' => 'nullable|file|extensions:glb|max:51200',
                    default => 'nullable|file|mimes:pdf|max:30720',
                };
            }
            if ($key === 'gallery') $rules['gallery_uploads.*'] = 'image|mimes:jpg,jpeg,png,webp|max:10240';
        }
        return $rules;
    }
    public function withValidator($validator): void {
        $validator->after(function ($validator) {
            if (filled($this->input('data.page_width')) !== filled($this->input('data.page_height'))) {
                $validator->errors()->add('data.page_width','Enter both page dimensions, or leave both blank to match the cover image.');
                $validator->errors()->add('data.page_height','Enter both page dimensions, or leave both blank to match the cover image.');
            }
            foreach (preg_split('/\R/', is_string($this->input('data.gallery')) ? $this->input('data.gallery') : '') as $path) {
                if (trim($path) && !preg_match('~^/(?!/)[a-zA-Z0-9/_\-.]+$~', trim($path))) $validator->errors()->add('data.gallery','Use local image paths, one per line.');
            }
        });
    }
}
