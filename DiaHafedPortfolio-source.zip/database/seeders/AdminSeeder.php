<?php
namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Seeder;
class AdminSeeder extends Seeder {
    public function run(): void {
        // Keep public portfolio contact details separate from administrator credentials.
        $email = env('ADMIN_EMAIL') ?: 'admin@example.test';

        $admin = User::firstOrNew(['email' => $email]);
        if (!$admin->exists) {
            $admin->name = 'Dia Hafed';
            $admin->password = 'password';
            $admin->is_admin = true;
            $admin->password_changed_at = null; // force a new password on first sign-in
            $admin->save();
        }
    }
}
