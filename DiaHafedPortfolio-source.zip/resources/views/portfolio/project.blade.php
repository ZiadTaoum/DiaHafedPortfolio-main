@extends('portfolio.layout')
@section('title', $project->title.' — '.($settings['name'] ?? 'Portfolio'))
@section('content')
@php
	$galleryPages = array_values(array_unique(array_filter(array_map('trim', preg_split('/\R/', (string) ($project->data['gallery'] ?? ''))))));
	$cover = trim((string) ($project->data['image'] ?? ''));
	$magazinePages = $cover !== ''
		? array_merge([$cover], array_values(array_filter($galleryPages, fn ($path) => $path !== $cover)))
		: $galleryPages;
	$isMagazine = strtolower($project->data['category'] ?? '') === 'editorial';
	$pageWidth = isset($project->data['page_width']) && is_numeric($project->data['page_width']) ? max(100, min(500, (int) $project->data['page_width'])) : 320;
	$pageHeight = isset($project->data['page_height']) && is_numeric($project->data['page_height']) ? max(100, min(500, (int) $project->data['page_height'])) : 300;
@endphp
<section class="section project-detail">
	<a class="text-link" href="{{ route('home') }}#{{ $project->section->key }}">← Back to selected work</a>
	<div class="section-heading">
		<div><span class="eyebrow">{{ $project->data['category'] ?? '' }} / {{ $project->data['year'] ?? '' }}</span><h1>{{ $project->title }}</h1></div>
		<p>{{ $project->subtitle }}<br>{{ $project->data['location'] ?? '' }}</p>
	</div>
	<div class="project-description prose">{{ $project->body }}</div>
	@if(!empty($project->data['model_url']))
		<div class="maquette-detail">
			<div class="maquette-heading"><div><span class="eyebrow">Interactive model</span><h2>Explore the maquette</h2></div><p>Drag to orbit · Scroll to zoom</p></div>
			<model-viewer class="maquette-viewer" data-model-viewer src="{{ $project->data['model_url'] }}" @if($cover !== '')poster="{{ $cover }}"@endif alt="Interactive 3D maquette of {{ $project->title }}" camera-controls auto-rotate shadow-intensity="1" exposure="1" ar ar-modes="webxr scene-viewer quick-look" loading="lazy" reveal="interaction"><span class="model-hint" slot="progress-bar">Preparing the model…</span><button class="ar-button" slot="ar-button" type="button">View in your space ↗</button></model-viewer>
		</div>
	@endif

	@if($isMagazine && count($magazinePages))
		<div class="offline-flipbook" data-offline-flipbook data-page-width="{{ $pageWidth }}" data-page-height="{{ $pageHeight }}" data-title="{{ $project->title }}" aria-label="{{ $project->title }} image flipbook">
			<div class="offline-flipbook-toolbar">
				<span class="eyebrow">{{ $project->title }}</span>
				<div class="offline-flipbook-controls">
					<span data-pageflip-count aria-live="polite">Page 1 of {{ count($magazinePages) }}</span>
					<button type="button" data-pageflip-prev aria-label="Previous page" disabled>←</button>
					<button type="button" data-pageflip-next aria-label="Next page">→</button>
				</div>
			</div>
			<div class="offline-flipbook-progress"><span data-pageflip-progress></span></div>
			<div class="offline-flipbook-stage">
				<div class="offline-flipbook-book" data-pageflip-book>
					@foreach($magazinePages as $path)
						<div class="offline-flipbook-page" @if($loop->first || $loop->last) data-density="hard" @endif>
							<img src="{{ $path }}" alt="{{ $loop->first && $cover !== '' ? ($project->data['image_alt'] ?? $project->title.' cover') : $project->title.' — page '.$loop->iteration }}" draggable="false">
							<span class="offline-page-number">{{ str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT) }}</span>
						</div>
					@endforeach
				</div>
			</div>
			<p class="offline-flipbook-hint">Use the arrows, swipe, or click a page corner to turn.</p>
		</div>
		@vite('resources/js/flipbook.js')
	@else
		@if($cover !== '')<button class="detail-image-trigger detail-cover-trigger" type="button" data-gallery-open data-gallery-src="{{ $cover }}" data-gallery-alt="{{ $project->data['image_alt'] ?? $project->title }}" aria-label="Inspect {{ $project->title }} image"><img class="detail-cover" src="{{ $cover }}" alt="{{ $project->data['image_alt'] ?? $project->title }}"><span class="image-inspect-label">Inspect image ↗</span></button>@endif
		@if(count($galleryPages))<p class="gallery-hint">Click an image to inspect it · use arrows or swipe to browse</p>@endif
		<div class="gallery">@foreach($galleryPages as $path)<button class="detail-image-trigger" type="button" data-gallery-open data-gallery-src="{{ $path }}" data-gallery-alt="{{ $project->title }} — project artwork {{ $loop->iteration }}" aria-label="Inspect project artwork {{ $loop->iteration }}"><img src="{{ $path }}" alt="{{ $project->title }} — project artwork {{ $loop->iteration }}" loading="lazy"><span class="image-inspect-label">Inspect ↗</span></button>@endforeach</div>
	@endif
	<dialog class="project-lightbox" data-project-lightbox aria-label="Project image viewer">
		<button class="lightbox-close" type="button" data-lightbox-close aria-label="Close image viewer">×</button>
		<button class="lightbox-arrow lightbox-previous" type="button" data-lightbox-previous aria-label="Previous image">←</button>
		<figure class="lightbox-figure" data-lightbox-stage><img data-lightbox-image alt=""><figcaption><span data-lightbox-caption></span><span data-lightbox-count></span></figcaption></figure>
		<button class="lightbox-arrow lightbox-next" type="button" data-lightbox-next aria-label="Next image">→</button>
		<button class="lightbox-zoom" type="button" data-lightbox-zoom aria-pressed="false">Zoom in +</button>
	</dialog>
	<script src="{{ asset('js/project-gallery.js') }}" defer></script>
</section>
@endsection
