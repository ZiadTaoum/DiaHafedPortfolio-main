<?php
namespace Tests\Feature;
use App\Models\{User,Section,PortfolioItem,ContactMessage};
use Database\Seeders\PortfolioSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\{Storage,Hash};
use Tests\TestCase;
class PortfolioTest extends TestCase {
    use RefreshDatabase;
    protected function setUp(): void { parent::setUp(); $this->seed(PortfolioSeeder::class); }
    private function admin(): User { $user=User::factory()->create(); $user->is_admin=true; $user->password_changed_at=now(); $user->save(); return $user; }
    private function values($record,array $overrides=[]): array { return array_replace(['title'=>$record->title,'subtitle'=>$record->subtitle,'body'=>$record->body,'position'=>$record->position,'is_visible'=>1,'data'=>$record->data],$overrides); }
    public function test_seeded_portfolio_and_all_projects_render(): void {
        $this->get('/')->assertOk()->assertSee('Dia Youssef Hafed')->assertSee('Architecture portfolio')->assertSee('Courtyard House')->assertDontSee('Najat Taoum');
        foreach(PortfolioItem::whereHas('section',fn($q)=>$q->where('type','projects'))->get() as $item) $this->get('/projects/'.$item->id)->assertOk()->assertSee($item->title);
        $project=PortfolioItem::where('title','Courtyard House')->firstOrFail();
        $this->get('/projects/'.$project->id)->assertOk()->assertSee('/images/architecture/project-residential.svg')->assertSee('SAMPLE CONCEPT')->assertSee('data-project-lightbox',false)->assertSee('data-gallery-open',false);
        $this->get('/')->assertSee('Residential')->assertSee('Civic & Culture')->assertSee('Urban Design');
    }
    public function test_cv_details_and_download_are_available(): void {
        $this->get('/')->assertSee('Bachelor of Architecture')->assertSee('Renovation Project Intern')->assertSee('AutoCAD')->assertSee('diahafed423@gmail.com');
        $this->get('/cv')->assertOk()->assertHeader('content-type','application/pdf');
    }
    public function test_seed_is_repeatable_and_preserves_edits_and_deletions(): void {
        $hero=Section::where('key','hero')->first(); $hero->update(['title'=>'Edited title']);
        $item=Section::where('key','projects')->first()->items()->first();$item->delete();
        $count=PortfolioItem::count();$this->seed(PortfolioSeeder::class);
        $this->assertSame(9,Section::count());$this->assertSame($count,PortfolioItem::count());$this->assertSame('Edited title',$hero->fresh()->title);
    }
    public function test_seed_contains_labeled_sample_studies_not_unverified_cv_entries(): void {
        $this->assertSame(['Courtyard House','Community Arts House','Lightwell Apartment','Street Commons','Material / Memory','Garden Room Pavilion'],PortfolioItem::whereHas('section',fn($q)=>$q->where('type','projects'))->orderBy('id')->pluck('title')->all());
        $this->assertSame(['Residential','Civic & Culture','Interior','Urban Design','Research','Landscape'],PortfolioItem::whereHas('section',fn($q)=>$q->where('type','projects'))->orderBy('id')->get()->pluck('data.category')->all());
        $this->assertDatabaseMissing('portfolio_items',['title'=>'Residential study']);
        $this->assertDatabaseMissing('portfolio_items',['title'=>'Dunes Magazine']);
        $this->assertDatabaseMissing('portfolio_items',['title'=>'Kava Shop']);
    }
    public function test_guests_and_non_admins_cannot_edit_content(): void {
        $section=Section::where('key','hero')->first();
        $this->get('/admin')->assertRedirect('/admin/login');
        $this->put('/admin/sections/'.$section->id,$this->values($section))->assertRedirect('/admin/login');
        $this->actingAs(User::factory()->create())->get('/admin')->assertForbidden();
    }
    public function test_admin_login_logout_and_invalid_credentials(): void {
        $user=$this->admin();$user->update(['password'=>Hash::make('test-password-123')]);
        $this->post('/admin/login',['email'=>$user->email,'password'=>'wrong'])->assertSessionHasErrors('email');
        $this->post('/admin/login',['email'=>$user->email,'password'=>'test-password-123'])->assertRedirect('/admin');$this->assertAuthenticatedAs($user);
        $this->post('/admin/logout')->assertRedirect('/');$this->assertGuest();
    }
    public function test_non_admin_cannot_log_in_to_dashboard(): void {
        $user=User::factory()->create(['password'=>Hash::make('test-password-123')]);
        $this->post('/admin/login',['email'=>$user->email,'password'=>'test-password-123'])->assertSessionHasErrors('email');$this->assertGuest();
    }
    public function test_all_admin_forms_render(): void {
        $this->actingAs($this->admin());$this->get('/admin')->assertOk();$this->get('/admin/account')->assertOk();$this->get('/admin/messages')->assertOk();
        foreach(Section::all() as $section){$this->get('/admin/sections/'.$section->id.'/edit')->assertOk();}
        foreach(PortfolioItem::all() as $item){$this->get('/admin/items/'.$item->id.'/edit')->assertOk();}
    }
    public function test_section_edits_visibility_and_order_affect_website(): void {
        $hero=Section::where('key','hero')->first();$this->actingAs($this->admin());
        $this->put('/admin/sections/'.$hero->id,$this->values($hero,['title'=>'A new story','position'=>1000]))->assertSessionHasNoErrors();
        $this->get('/')->assertSeeInOrder(['Architecture portfolio','A new story']);
        $this->put('/admin/sections/'.$hero->id,$this->values($hero,['is_visible'=>0]))->assertSessionHasNoErrors();
        $this->get('/')->assertDontSee('A new story');
    }
    public function test_project_crud_and_hidden_project_access(): void {
        $section=Section::where('key','projects')->first();$this->actingAs($this->admin());
        $this->post('/admin/sections/'.$section->id.'/items',['title'=>'New project','position'=>0,'is_visible'=>1,'data'=>['category'=>'Branding']])->assertSessionHasNoErrors();
        $item=PortfolioItem::where('title','New project')->firstOrFail();$this->get('/projects/'.$item->id)->assertOk();
        $this->put('/admin/items/'.$item->id,$this->values($item,['is_visible'=>0]))->assertSessionHasNoErrors();$this->get('/projects/'.$item->id)->assertNotFound();
        $this->delete('/admin/items/'.$item->id)->assertRedirect();$this->assertDatabaseMissing('portfolio_items',['id'=>$item->id]);
    }
    public function test_hidden_project_section_hides_detail_pages(): void {
        $section=Section::where('key','projects')->first();$item=$section->items()->first();$section->update(['is_visible'=>false]);$this->get('/projects/'.$item->id)->assertNotFound();
    }
    public function test_uploads_are_stored_and_served_and_unsafe_uploads_rejected(): void {
        Storage::fake('local');$this->actingAs($this->admin());$section=Section::where('key','hero')->first();
        $this->put('/admin/sections/'.$section->id,$this->values($section,['upload_image'=>UploadedFile::fake()->image('cover.jpg')]))->assertSessionHasNoErrors();
        $path=$section->fresh()->data['image'];$this->assertStringStartsWith('/media/uploads/',$path);$this->get($path)->assertOk()->assertHeader('X-Content-Type-Options','nosniff');
        $this->put('/admin/sections/'.$section->id,$this->values($section,['upload_image'=>UploadedFile::fake()->create('script.php',1,'text/x-php')]))->assertSessionHasErrors('upload_image');
        $this->get('/media/uploads/not-found.jpg')->assertNotFound();
    }
    public function test_gallery_upload_and_unsafe_links(): void {
        Storage::fake('local');$this->actingAs($this->admin());$item=Section::where('key','projects')->first()->items()->first();
        $this->put('/admin/items/'.$item->id,$this->values($item,['gallery_uploads'=>[UploadedFile::fake()->image('art.jpg')]]))->assertSessionHasNoErrors();
        $this->assertStringContainsString('/media/uploads/',$item->fresh()->data['gallery']);
        $hero=Section::where('key','hero')->first();$data=$hero->data;$data['cta_url']='javascript:alert(1)';
        $this->put('/admin/sections/'.$hero->id,$this->values($hero,['data'=>$data]))->assertSessionHasErrors('data.cta_url');
    }
    public function test_contact_validates_saves_and_admin_manages_message(): void {
        $this->post('/contact',['name'=>'Visitor','email'=>'bad','message'=>'short'])->assertSessionHasErrors(['email','message']);
        $this->post('/contact',['name'=>'Visitor','email'=>'visitor@example.com','message'=>'I would like a brand identity.'])->assertSessionHas('contact_success');
        $message=ContactMessage::firstOrFail();$this->actingAs($this->admin());$this->get('/admin/messages')->assertOk()->assertSee('Visitor');
        $this->patch('/admin/messages/'.$message->id)->assertRedirect();$this->assertNotNull($message->fresh()->read_at);
        $this->delete('/admin/messages/'.$message->id)->assertRedirect();$this->assertDatabaseCount('contact_messages',0);
    }
    public function test_account_password_change_requires_current_password(): void {
        $user=$this->admin();$this->actingAs($user);
        $this->put('/admin/account',['name'=>'Dia Hafed','email'=>$user->email,'current_password'=>'wrong','password'=>'new-password-123','password_confirmation'=>'new-password-123'])->assertSessionHasErrors('current_password');
        $this->put('/admin/account',['name'=>'Dia Hafed','email'=>$user->email,'current_password'=>'password','password'=>'new-password-123','password_confirmation'=>'new-password-123'])->assertSessionHasNoErrors();
        $this->assertTrue(Hash::check('new-password-123',$user->fresh()->password));
    }
    public function test_first_sign_in_forces_password_change_before_dashboard(): void {
        $user=User::factory()->create(['password'=>'password']);$user->is_admin=true;$user->password_changed_at=null;$user->save();
        $this->post('/admin/login',['email'=>$user->email,'password'=>'password'])->assertRedirect('/admin');
        // Dashboard and content pages redirect to the password form until a new password is set.
        $this->get('/admin')->assertRedirect('/admin/password');
        $this->get('/admin/messages')->assertRedirect('/admin/password');
        $this->get('/admin/password')->assertOk()->assertSee('Choose your password');
        // Weak or mismatched passwords are rejected.
        $this->put('/admin/password',['current_password'=>'password','password'=>'short','password_confirmation'=>'short'])->assertSessionHasErrors('password');
        $this->put('/admin/password',['current_password'=>'wrong','password'=>'brand-new-password-123','password_confirmation'=>'brand-new-password-123'])->assertSessionHasErrors('current_password');
        // A valid new password clears the flag and unlocks the dashboard.
        $this->put('/admin/password',['current_password'=>'password','password'=>'brand-new-password-123','password_confirmation'=>'brand-new-password-123'])->assertRedirect('/admin');
        $this->assertNotNull($user->fresh()->password_changed_at);
        $this->assertTrue(Hash::check('brand-new-password-123',$user->fresh()->password));
        $this->get('/admin')->assertOk();
    }
    public function test_admin_seeder_uses_non_routable_email_and_default_password(): void {
        $this->seed(\Database\Seeders\AdminSeeder::class);
        $user=User::where('is_admin',true)->firstOrFail();
        $this->assertSame('admin@example.test',$user->email);
        $this->assertTrue(Hash::check('password',$user->password));
        $this->assertNull($user->password_changed_at);
    }
    public function test_admin_colors_persist_and_apply_to_home_and_project_pages(): void {
        $settings=Section::where('key','settings')->first();
        $this->actingAs($this->admin());
        $this->get('/admin/sections/'.$settings->id.'/edit')->assertOk()->assertSee('Website colors');
        $data=[...$settings->data,'color_accent'=>'#2266aa','color_background'=>'#fafafa'];
        $this->put('/admin/sections/'.$settings->id,$this->values($settings,['data'=>$data]))->assertSessionHasNoErrors();
        $this->assertSame('#2266aa',$settings->fresh()->data['color_accent']);
        $this->get('/')->assertOk()->assertSee('--orange:#2266aa;',false)->assertSee('--paper:#fafafa;',false);
        $project=Section::where('key','projects')->first()->items()->first();
        $this->get('/projects/'.$project->id)->assertOk()->assertSee('--orange:#2266aa;',false);
        $this->seed(PortfolioSeeder::class);
        $this->assertSame('#2266aa',$settings->fresh()->data['color_accent']);
    }
    public function test_invalid_colors_are_rejected_and_legacy_settings_use_defaults(): void {
        $settings=Section::where('key','settings')->first();
        $this->actingAs($this->admin());
        $this->put('/admin/sections/'.$settings->id,$this->values($settings,['data'=>[...$settings->data,'color_accent'=>'red;}</style><script>alert(1)</script>']]))->assertSessionHasErrors('data.color_accent');
        $this->assertArrayNotHasKey('color_accent',$settings->fresh()->data);
        $this->get('/')->assertSee('--orange:#b47a52;',false);
        $settings->update(['data'=>[...$settings->data,'color_accent'=>'invalid']]);
        $this->get('/')->assertSee('--orange:#b47a52;',false)->assertDontSee('--orange:invalid',false);
    }
}
